package com.example.alimentarpeixe

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/** Aquário com peixe ASCII, flocos de comida, bolhas e "crunch", como no vídeo. */
class AquariumView(context: Context) : View(context) {

    private class Flake(var x: Float, var y: Float, val vy: Float, val drift: Float)
    private class Bubble(var x: Float, var y: Float, val r: Float, val vy: Float)
    private class Crunch(val x: Float, val y: Float, var life: Float)

    private val flakes = mutableListOf<Flake>()
    private val bubbles = mutableListOf<Bubble>()
    private val crunches = mutableListOf<Crunch>()

    private val fishPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255); typeface = Typeface.MONOSPACE; textSize = 64f
        setShadowLayer(18f, 0f, 0f, Color.CYAN)
    }
    private val flakePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 193, 7) }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(64, 156, 255); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val plantPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 255, 120); typeface = Typeface.MONOSPACE; textSize = 70f
    }
    private val crunchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 235, 130); typeface = Typeface.MONOSPACE; textSize = 34f
    }
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255); textSize = 36f
    }

    private var fishX = 300f
    private var fishY = 600f
    private var facingRight = true
    private var t = 0f
    private var lastNs = 0L
    var status: String = ""

    private val right = "><(((o>"
    private val left = "<o)))><"

    fun feed() {
        if (width == 0) return
        repeat(45) {
            flakes += Flake(
                Random.nextFloat() * width * 0.7f + width * 0.15f,
                -Random.nextFloat() * 200f,
                120f + Random.nextFloat() * 90f,
                (Random.nextFloat() - 0.5f) * 40f
            )
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceAtMost(0.05f)
        lastNs = now
        t += dt
        c.drawColor(Color.BLACK)
        update(dt)

        // plantas
        val base = height - 120f
        for (i in 0..5) {
            val px = width * (0.1f + i * 0.16f)
            c.drawText(if (i % 2 == 0) "§" else "{", px + sin(t * 1.5f + i) * 8f, base, plantPaint)
        }
        // bolhas
        for (b in bubbles) c.drawCircle(b.x, b.y, b.r, bubblePaint)
        // comida
        for (f in flakes) c.drawCircle(f.x, f.y, 6f, flakePaint)
        // crunch
        for (cr in crunches) {
            crunchPaint.alpha = (255 * cr.life.coerceIn(0f, 1f)).toInt()
            c.drawText("*crunch*", cr.x - 70f, cr.y - 40f, crunchPaint)
        }
        // peixe
        c.drawText(if (facingRight) right else left, fishX, fishY, fishPaint)
        status.split("\n").forEachIndexed { i, l -> c.drawText(l, 32f, 90f + i * 46f, hudPaint) }
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val target = flakes.filter { it.y > 0 }.minByOrNull { abs(it.x - fishX) + abs(it.y - fishY) }
        val speed = if (target != null) 330f else 110f

        if (target != null) {
            facingRight = target.x > fishX
            fishX += (if (facingRight) 1 else -1) * speed * dt
            fishY += (target.y - fishY).coerceIn(-1f, 1f) * 200f * dt
        } else {
            fishX += (if (facingRight) 1 else -1) * speed * dt
            fishY = h * 0.5f + sin(t * 0.8f) * h * 0.12f
            if (fishX > w - 380f) facingRight = false
            if (fishX < 20f) facingRight = true
        }

        // comer
        val mouthX = fishX + (if (facingRight) 330f else 10f)
        val it = flakes.iterator()
        while (it.hasNext()) {
            val f = it.next()
            f.y += f.vy * dt; f.x += f.drift * dt
            if (abs(f.x - mouthX) < 70f && abs(f.y - (fishY - 20f)) < 60f) {
                crunches += Crunch(mouthX, fishY, 1f); it.remove()
            } else if (f.y > h) it.remove()
        }
        crunches.removeAll { it.life <= 0f }
        crunches.forEach { it.life -= dt * 1.2f }

        // bolhas
        if (Random.nextFloat() < 0.04f + (if (target != null) 0.1f else 0f))
            bubbles += Bubble(fishX + Random.nextFloat() * 300f, fishY, 5f + Random.nextFloat() * 8f, 90f + Random.nextFloat() * 80f)
        bubbles.forEach { it.y -= it.vy * dt }
        bubbles.removeAll { it.y < -20f }
    }
}
