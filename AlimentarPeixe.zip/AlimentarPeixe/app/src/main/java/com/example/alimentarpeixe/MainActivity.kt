package com.example.alimentarpeixe

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.*
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    // ===== AJUSTES =====
    private val usarNfc = true              // alimenta ao encostar o relógio (ou qualquer NFC) no celular
    private val usarBluetooth = false       // alimenta ao chegar perto (sinal Bluetooth). Ligue se quiser
    private val nomeDoRelogio = "Watch"
    private var limiteRssi = -60
    private val intervaloNfcMs = 5_000L
    private val intervaloBluetoothMs = 30_000L
    // ===================

    private lateinit var aquario: AquariumView
    private val handler = Handler(Looper.getMainLooper())
    private var nfc: NfcAdapter? = null
    private var perto = false
    private var ultimoPerto = 0L
    private var ultimaAlimentacao = 0L
    private var ultimoRssi = 0
    private var ultimoNfc = "nada ainda"
    private var scanner: BluetoothLeScanner? = null
    private var btIniciado = false

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val nome = try { r.device.name ?: r.scanRecord?.deviceName } catch (e: SecurityException) { null }
            if (nome == null || !nome.contains(nomeDoRelogio, true)) return
            ultimoRssi = r.rssi
            if (r.rssi >= limiteRssi) {
                ultimoPerto = SystemClock.elapsedRealtime()
                if (!perto) { perto = true; alimentar(intervaloBluetoothMs) }
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (perto && SystemClock.elapsedRealtime() - ultimoPerto > 8000) perto = false
            val n = nfc
            val nfcTxt = when {
                !usarNfc -> "desligado"
                n == null -> "não existe"
                !n.isEnabled -> "DESLIGADO no celular"
                else -> "ligado"
            }
            aquario.status = "NFC: $nfcTxt ($ultimoNfc)" +
                if (usarBluetooth) "\nBT: ${if (perto) "PERTO" else "longe"} RSSI $ultimoRssi" else ""
            handler.postDelayed(this, 500)
        }
    }

    private fun alimentar(intervalo: Long) {
        val agora = SystemClock.elapsedRealtime()
        if (agora - ultimaAlimentacao >= intervalo) {
            ultimaAlimentacao = agora
            runOnUiThread { aquario.feed() }
        }
    }

    private fun aoDetectarNfc() {
        ultimoNfc = "detectado " + java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())
        alimentar(intervaloNfcMs)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        aquario = AquariumView(this)
        val raiz = FrameLayout(this)
        raiz.addView(aquario)
        val btn = Button(this).apply {
            text = "Alimentar (teste)"
            setOnClickListener { ultimaAlimentacao = 0; alimentar(0) }
        }
        raiz.addView(btn, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 120 })
        setContentView(raiz)
        nfc = NfcAdapter.getDefaultAdapter(this)
        if (usarBluetooth) pedirPermissoesBt()
        handler.post(tick)
        // app aberto pelo NFC
        if (intent?.action == NfcAdapter.ACTION_TECH_DISCOVERED) handler.postDelayed({ aoDetectarNfc() }, 700)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        if (i.action == NfcAdapter.ACTION_TECH_DISCOVERED || i.action == NfcAdapter.ACTION_TAG_DISCOVERED) aoDetectarNfc()
    }

    override fun onResume() {
        super.onResume()
        if (usarNfc) {
            nfc?.enableReaderMode(
                this,
                NfcAdapter.ReaderCallback { aoDetectarNfc() },
                NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK or NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS,
                null
            )
        }
    }

    override fun onPause() {
        super.onPause()
        try { nfc?.disableReaderMode(this) } catch (_: Exception) {}
    }

    private fun pedirPermissoesBt() {
        val p = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (p.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) iniciarBt()
        else requestPermissions(p, 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) iniciarBt()
    }

    private fun iniciarBt() {
        if (btIniciado) return
        btIniciado = true
        val bm = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = bm.adapter?.bluetoothLeScanner
        scanner?.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { scanner?.stopScan(scanCb) } catch (_: Exception) {}
        handler.removeCallbacksAndMessages(null)
    }
}
